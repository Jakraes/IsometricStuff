package com.iso.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;
import com.iso.game.Map.AbstractMap;
import com.iso.game.Map.Chunk;
import com.iso.game.Map.WorldMap;
import com.iso.game.Tiles.AbstractTile;
import com.iso.game.Tiles.TileAir;

public class Game extends ApplicationAdapter {
	SpriteBatch batch;
	int posX = 0, posY = 0;
	int zoom = 1;


	WorldMap map;

	@Override
	public void create () {
		batch = new SpriteBatch();
		map = new WorldMap(0, 0.05f);
	}

	@Override
	public void render () {
		ScreenUtils.clear(0, 0, 0, 1);

		if (Gdx.input.isKeyJustPressed(Input.Keys.UP)) posX += 1;
		if (Gdx.input.isKeyJustPressed(Input.Keys.DOWN)) posX -= 1;
		if (Gdx.input.isKeyJustPressed(Input.Keys.RIGHT)) posY -= 1;
		if (Gdx.input.isKeyJustPressed(Input.Keys.LEFT)) posY += 1;

		batch.begin();

		int xSize = 16, ySize = 16, zSize = 16;

		for (int y = ySize * 3 - 1; y >= 0; y--) {
			for (int x = 0; x < xSize * 3; x++) {
				Chunk c = map.getChunk(posX - 1 + (int) x / 16, posY - 1 + (int) y / 16);
				for (int z = 0; z < zSize; z++) {
					int destX = (x + y) * (16 * zoom) / 2;
					int destY = (y - x + z) * (16 * zoom) / 4;

					int tileX = x - ((int) (x / 16)) * 16;
					int tileY = y - ((int) (y / 16)) * 16;
					int tileZ = z - ((int) (z / 16)) * 16;

					AbstractTile t = c.getTile(tileX, tileY, tileZ);
					if (t instanceof TileAir) continue;

					batch.draw(t.getTexture(), destX + 16, destY+ 200, 16 * zoom, 16 * zoom);
				}
			}
		}

		batch.end();
	}

	@Override
	public void dispose () {
		batch.dispose();
	}
}
