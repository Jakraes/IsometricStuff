package com.iso.game.Map;

import com.iso.game.SimplexNoise;
import com.iso.game.Tiles.TileDirt;
import com.iso.game.Tiles.TileGrass;

public class WorldMap extends AbstractMap {
    private final int CHUNK_WIDTH = 16, CHUNK_DEPTH = 16, CHUNK_HEIGHT = 16;

    public WorldMap(int seed, float step) {
        super(seed, step);
    }

    @Override
    public Chunk generateChunk(int x, int y) {
        Chunk result = new Chunk(CHUNK_WIDTH, CHUNK_DEPTH, CHUNK_HEIGHT);

        for (int yTemp = 0; yTemp < CHUNK_DEPTH; yTemp++) {
            for (int xTemp = 0; xTemp < CHUNK_WIDTH; xTemp++) {
                int height = (int) ((SimplexNoise.noise(x * CHUNK_WIDTH + xTemp * getStep() + getSeed(), y * CHUNK_DEPTH + yTemp * getStep() + getSeed()) + 1) / 2 * CHUNK_HEIGHT);
                result.setTile(xTemp, yTemp, height, new TileGrass());
                for (int z = 0; z < height; z++) {
                    result.setTile(xTemp, yTemp, z, new TileDirt());
                }
            }
        }

        return result;
    }
}
