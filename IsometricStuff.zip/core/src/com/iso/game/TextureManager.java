package com.iso.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;
import com.sun.rowset.internal.Row;

public class TextureManager {
    private static final int TEXTUREHEIGHT = 16;
    private static final int TEXTUREWIDTH = 16;
    private static final int ROWS = 1;
    private static final int COLS = 5;
    private static TextureManager instance;

    private static Texture tex;
    private static Array<TextureRegion> textures;

    public static TextureManager getInstance() {
        if (instance == null) instance = new TextureManager();
        return instance;
    }

    private TextureManager() {
        tex = new Texture(Gdx.files.internal("tiles.png"));
        textures = new Array<>();

        for (int y = 0; y < ROWS; y++) {
            for (int x = 0; x < COLS; x++) {
                textures.add(new TextureRegion(tex, x * TEXTUREWIDTH, y * TEXTUREHEIGHT, TEXTUREWIDTH, TEXTUREHEIGHT));
            }
        }
    }

    public TextureRegion getTexture(int index) {
        return textures.get(index);
    }

    public void dispose() {
        if (instance == null) return;
        tex.dispose();
    }
}
