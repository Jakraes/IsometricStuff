package com.iso.game.Tiles;

public class TileGrass extends AbstractTile {

    public TileGrass() {
        super(1);
    }
}
