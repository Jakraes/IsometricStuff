package com.iso.game.Tiles;

public class TileDirt extends AbstractTile {

    public TileDirt() {
        super(2);
    }
}
