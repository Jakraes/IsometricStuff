package com.iso.game.Tiles;

public class TileAir extends AbstractTile {

    public TileAir() {
        super(0);
    }
}
